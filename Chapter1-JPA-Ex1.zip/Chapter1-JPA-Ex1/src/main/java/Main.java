import fu.se123456.dao.EmployeeDAO;
import fu.se123456.pojo.Employee;
import fu.se123456.pojo.Gender;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        EmployeeDAO dao = new EmployeeDAO();

        System.out.println("==================================================");
        System.out.println("DEMO CRUD VA KIEM CHUNG ENTITY LIFECYCLE (HSF302)");
        System.out.println("==================================================");

        // ==========================================
        // 1. CREATE (TODO 0.3, TODO 0.8, TODO 0.10)
        // ==========================================
        // [Lifecycle] emp duoc tao bang tu khoa new, chua gan voi EntityManager nao,
        // chua co ID -> trang thai NEW / TRANSIENT.
        Employee emp = new Employee("Nguyen Van A", "a@fpt.edu.vn",
                new BigDecimal("15000000"), Gender.MALE, LocalDate.of(2022, 3, 1));

        System.out.println("\n[1. CREATE] Truoc khi save, ID: " + emp.getId()); // ID van la null
        dao.save(emp);

        // [Lifecycle] Trong dao.save(): khi em.persist(emp) duoc goi, emp chuyen sang MANAGED.
        // Sau khi em.getTransaction().commit() va em.close(), EntityManager da dong
        // -> emp chuyen sang trang thai DETACHED (van con ID va du lieu nhung khong con duoc quan ly).
        System.out.println("[1. CREATE] Sau khi save, ID duoc sinh: " + emp.getId());
        System.out.println("[1. CREATE] Thong tin Employee: " + emp);

        // ==========================================
        // 2. READ: findById & findAll (TODO 0.4, TODO 0.8)
        // ==========================================
        // [Lifecycle] Ben trong dao.findById(): em.find() tra ve entity o trang thai MANAGED.
        // Khi method return va em.close() thuc thi trong finally, object 'found' tro thanh DETACHED.
        Employee found = dao.findById(emp.getId());
        System.out.println("\n[2. READ] Doc lai bang findById: " + found);

        List<Employee> allEmployees = dao.findAll();
        System.out.println("[2. READ] Tong so nhan vien hien co (findAll): " + allEmployees.size());

        // ==========================================
        // 3. READ CO DIEU KIEN (TODO 0.5)
        // ==========================================
        Employee byEmail = dao.findByEmail("a@fpt.edu.vn");
        System.out.println("\n[3. CONDITIONAL READ] Tim theo email a@fpt.edu.vn: " + byEmail);

        List<Employee> highSalary = dao.findBySalaryGreaterThanAndActive(new BigDecimal("10000000"));
        System.out.println("[3. CONDITIONAL READ] Nhan vien luong > 10,000,000 & active: " + highSalary.size());

        // ==========================================
        // 4. UPDATE (TODO 0.6, TODO 0.8, TODO 0.10)
        // ==========================================
        // [Lifecycle] 'found' dang o trang thai DETACHED.
        // Thay doi gia tri salary tren found o day CHUA lam thay doi du lieu trong CSDL.
        found.setSalary(new BigDecimal("22000000"));
        System.out.println("\n[4. UPDATE] Sua salary tren object Detached thanh: " + found.getSalary());

        // [Lifecycle] Trong dao.update(): em.merge(found) duoc goi.
        // Hibernate copy trang thai tu 'found' sang mot ban the entity moi trong persistence context,
        // ban the nay la MANAGED. Khi transaction commit, Hibernate thuc hien UPDATE xuong DB.
        // Sau khi update() return va em.close(), object 'updated' tro ve trang thai DETACHED.
        // Luu y: 'found' ban dau van la Detached cu, ta nen su dung 'updated' tra ve tu merge().
        Employee updated = dao.update(found);
        System.out.println("[4. UPDATE] Sau dao.update(), object merge tra ve: " + updated);

        // Doc lai tu CSDL de kiem chung gia tri moi da duoc persist thanh cong
        Employee reChecked = dao.findById(emp.getId());
        System.out.println("[4. UPDATE] Doc lai tu DB de kiem tra salary moi: " + reChecked.getSalary());

        // ==========================================
        // 5. DELETE (TODO 0.7, TODO 0.8, TODO 0.10)
        // ==========================================
        // [Lifecycle] Trong dao.delete(): em.find() lay ra entity o trang thai MANAGED.
        // em.remove(e) chuyen entity sang trang thai REMOVED.
        // Khi commit(), lenh DELETE duoc thuc thi xuong DB.
        dao.delete(emp.getId());
        System.out.println("\n[5. DELETE] Da goi dao.delete cho ID: " + emp.getId());

        // Doc lai sau khi xoa: ky vong tra ve null
        Employee afterDelete = dao.findById(emp.getId());
        System.out.println("[5. DELETE] Tim lai sau khi xoa (ky vong null): " + afterDelete);

        // ==========================================
        // 6. KIEM CHUNG UNIQUE EMAIL (TODO 0.9)
        // ==========================================
        System.out.println("\n[6. UNIQUE CONSTRAINT] Kiem chung rang buoc unique tren email:");
        Employee emp1 = new Employee("Tran Thi B", "unique_test@fpt.edu.vn",
                new BigDecimal("12000000"), Gender.FEMALE, LocalDate.now());
        Employee emp2 = new Employee("Le Van C", "unique_test@fpt.edu.vn", // trung email
                new BigDecimal("14000000"), Gender.MALE, LocalDate.now());

        dao.save(emp1);
        System.out.println("  -> Da luu emp1 thanh cong voi email: " + emp1.getEmail());

        try {
            System.out.println("  -> Dang co y luu emp2 voi cung email...");
            dao.save(emp2);
            System.out.println("  -> CANH BAO: Khong bat duoc exception vi pham unique!");
        } catch (RuntimeException ex) {
            System.out.println("  -> Da chan va bat duoc exception vi pham unique email nhu ky vong:");
            System.out.println("     Loai loi: " + ex.getClass().getName());
            System.out.println("     Nguyen nhan: " + (ex.getCause() != null ? ex.getCause().getMessage() : ex.getMessage()));
        } finally {
            // Don dep du lieu test emp1
            dao.delete(emp1.getId());
            System.out.println("  -> Da don dep du lieu test.");
        }

        System.out.println("\n==================================================");
        System.out.println("HOAN THANH TAT CA CAC TODO CHO BAI 0 JPA BASIC!");
        System.out.println("==================================================");

        EmployeeDAO.closeFactory();
    }
}
